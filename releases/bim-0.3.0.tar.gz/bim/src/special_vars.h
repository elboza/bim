/*
 * author: Fernando Iazeolla
 * license: GPLv2
 */

#ifndef SPECIAL_VARS_H
#define SPECIAL_VARS_H

#define LAST_EVAL_VAL_STR "\""$!"\""

#endif